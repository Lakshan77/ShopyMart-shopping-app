package com.lakshanandroid.shopymart.Prevalent;

import com.lakshanandroid.shopymart.Model.Users;

public class Prevalent {

    public static Users currentOnlineUsers;

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";


}
